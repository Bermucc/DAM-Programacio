package com.exercici1301;

interface Nedador {
    void nedar();
}

class nadando {
    public void nedar(){
        System.out.println("El animal esta nadando");
    }
}
