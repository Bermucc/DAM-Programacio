package com.exercici1301;

interface Volador {
    void volar();
} 

class volando {
    public void volar(){
        System.out.println("El animal esta volando");
    }
}

